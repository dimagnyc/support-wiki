# 🧰 Support Wiki

This is a personal knowledge base of real-world fixes, system configurations, and support solutions collected over my 16+ years in technical support roles.

## Topics Covered

- Common Windows issues
- Active Directory management tips
- Remote support tools
- VPN troubleshooting
- Cloud resource handling (Azure / GCP)
- Ticket response templates

> This wiki is a work in progress and updated frequently.
